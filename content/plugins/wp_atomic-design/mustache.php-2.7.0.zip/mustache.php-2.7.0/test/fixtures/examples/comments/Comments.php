<?php

class Comments
{
    public function title()
    {
        return 'A Comedy of Errors';
    }
}
